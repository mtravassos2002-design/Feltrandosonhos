# Regras adicionais de ProGuard podem ser colocadas aqui.
