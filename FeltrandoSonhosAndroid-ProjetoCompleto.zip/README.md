# Feltrando Sonhos — Android

Projeto Android pronto para gerar um APK.

## O que já está incluído
- Tela inicial
- Catálogo de moldes
- Categorias
- Área Meus Moldes
- Perfil
- Botões de compra
- Checkout Kiwify configurado no código
- Interface adaptada para celular

## Gerar APK
O workflow em `.github/workflows/build-apk.yml` gera automaticamente um APK de debug.

Após enviar este projeto para um repositório GitHub:
1. Abra a aba Actions.
2. Execute **Build APK**.
3. Baixe o artefato `FeltrandoSonhos-debug-apk`.

O APK gerado é uma versão de teste. Antes de publicar na Play Store, devemos configurar assinatura de release e os dados finais do aplicativo.
